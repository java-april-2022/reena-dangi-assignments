Evening Agenda:  Week4- Session2 
# 4:00 PST-  Office Hour
# 5:00 PST-  Lecture

## HouseKeeping
- Office hrs - MYSql  
- Project for this week 
- Assignments for Week4 

## Topics
- MySQL
- JPA
- Spring MVC
- Add NFT Art
- @ModelAttribute
- Update 
- Delete 
- View Details 