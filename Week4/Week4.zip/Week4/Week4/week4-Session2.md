Evening Agenda:  Week4- Session2 
# 4:00 PST-  Office Hour
# 5:00 PST-  Lecture

## HouseKeeping
- Assignments for this week 
- Mid stack survey - Really important for us 
- It's not a Good Bye :(

## Topics
- Add NFT Art
- @ModelAttribute
- Validations
- Update 
- Delete 
- View Details 